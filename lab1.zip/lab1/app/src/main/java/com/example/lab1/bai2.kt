package com.example.lab1


    fun main(){
        println("Phùng Đức Tâm - PH33277\n")
        println("=======================\n")
        println("Quanh năm buôn bán ở mom sông")
        println("Nuôi đủ năm con với một chồng")
        println("\tlăn lội thân cò khi quãng vắng")
        println("\teo sèo mặt nước buổi đò đồng")
        println("Một duyên 2 nợ âu dành phận")
        println("Nặn nắng mười mưa hả chăng công")
        println("\tCha mẹ thói đời \"ăn ở bạc\" ")
        println("\tCó chồng hờ hững cũng như không")
    }
