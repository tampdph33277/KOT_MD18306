package com.example.lab3

open class Nguoi(var hoTen: String,
                 var tuoi: Int,
                 var queQuan: String)