package com.example.lab3

class SinhVien(
    val hoTen: String,
    val tuoi: Int,
    val lop: String
)